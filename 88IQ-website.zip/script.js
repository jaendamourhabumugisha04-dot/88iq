const questions=[
 {q:"Which organelle is mainly responsible for producing ATP in cells?",o:["Nucleus","Mitochondrion","Ribosome","Cell wall"],a:1},
 {q:"If 2x + 6 = 14, what is x?",o:["2","3","4","5"],a:2},
 {q:"What is the SI unit of force?",o:["Joule","Watt","Newton","Pascal"],a:2},
 {q:"Which gas is most abundant in Earth's atmosphere?",o:["Oxygen","Nitrogen","Carbon dioxide","Hydrogen"],a:1}
];
let qIndex=-1,score=0,answered=false;
function toggleMenu(){const n=document.querySelector("nav");n.style.display=n.style.display==="flex"?"none":"flex"}
function filterSubjects(){const v=document.getElementById("search").value.toLowerCase();document.querySelectorAll(".subject").forEach(c=>c.style.display=c.innerText.toLowerCase().includes(v)?"block":"none")}
function startSubject(name){document.getElementById("quiz").scrollIntoView({behavior:"smooth"});document.getElementById("quizQuestion").innerText="Practice ya "+name+" izatangira vuba. Koresha quiz rusange hano.";document.getElementById("quizOptions").innerHTML="";}
function nextQuestion(){if(qIndex>=0&&!answered)return; qIndex++;answered=false;if(qIndex>=questions.length){document.getElementById("quizQuestion").innerText="Quiz irarangiye!";document.getElementById("quizOptions").innerHTML="";document.getElementById("quizBtn").innerText="Ongera Utangire";document.getElementById("score").innerText="Amanota: "+score+" / "+questions.length;qIndex=-1;score=0;return}const x=questions[qIndex];document.getElementById("quizQuestion").innerText=(qIndex+1)+". "+x.q;document.getElementById("quizOptions").innerHTML=x.o.map((v,i)=>`<button class="option" onclick="answer(${i})">${v}</button>`).join("");document.getElementById("quizBtn").innerText="Ikibazo gikurikira";document.getElementById("score").innerText="";}
function answer(i){if(answered)return;answered=true;const x=questions[qIndex];document.querySelectorAll(".option").forEach((b,n)=>{if(n===x.a)b.classList.add("correct");if(n===i&&i!==x.a)b.classList.add("wrong")});if(i===x.a)score++}
function register(e){e.preventDefault();const name=document.getElementById("studentName").value;localStorage.setItem("88iq_student",JSON.stringify({name,cls:document.getElementById("studentClass").value,email:document.getElementById("studentEmail").value}));document.getElementById("registerMsg").innerText="Murakoze "+name+"! Profile yabitswe kuri iyi browser."}
window.addEventListener("load",()=>{const s=localStorage.getItem("88iq_student");if(s){const x=JSON.parse(s);document.getElementById("registerMsg").innerText="Murakaza neza "+x.name+"!"}});
